package com.harshbhavsar.flutter_ui_collections;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
